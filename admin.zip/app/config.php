<?php

define('PATH', realpath('.'));
define('SUBFOLDER', false);
define('URL', 'https://litepanel.tk/');
define('STYLESHEETS_URL', '//litepanel.tk/');

error_reporting(1);
date_default_timezone_set('Asia/Kolkata');

return [
  'db' => [
    'name'    =>  'litepane_free',
    'host'    =>  'localhost',
    'user'    =>  'litepane_free',
    'pass'    =>  'z7!oBEKF4^37',
    'charset' =>  'utf8mb4' 
  ]
];
